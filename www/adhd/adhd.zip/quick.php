<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>注意力缺陷障碍（成人多动症，ADD/ADHD）快速测试</title>
<link rel="canonical" href="http://soulogic.com/adhd/quick.php" />
<link rel="stylesheet" href="style.css" type="text/css" />
<script type="text/javascript" src="script.js"></script>
</head>

<body>

<?PHP
$aQuestion = array(
	'How often do you have trouble wrapping up the final details of a project, once the challenging parts have been done?',
	'How often do you have difficulty getting things in order when you have to do a task that requires organization?',
	'How often do you have problems remembering appointments or obligations?',
	'When you have a task that requires a lot of thought, how often do you avoid or delay getting started?',
	'How often do you fidget or squirm with your hands or feet when you have to sit down for a long time?',
	'How often do you feel overly active and compelled to do things, like you were driven by a motor?',
);

$aAnswer = array(
	'Never',
	'Rarely',
	'Sometimes',
	'Often',
	'Very Often',
);
?>
<div style="width: 960px; margin: 0 auto;">
<h1>注意力缺陷障碍（成人多动症，ADD/ADHD）快速测试</h1>

<p class="author">Jasper/Goldberg Adult ADD/ADHD Screening Quiz<br />
by Larry Jasper & Ivan Goldberg</p>


<p class="description">Use this questionnaire to help determine if you need to see a mental health professional for diagnosis and treatment of ADD or ADHD in an adult. Based upon the Adult ADHD Self-Report Scale (ASRS-v1.1) Symptom Checklist. We also have a <a href="./">slightly longer ADD quiz</a>.</p>
<p class="description"><b>Instructions:</b> This is a quick, 6 question screening measure. Please answer the questions below, rating yourself on each of the criteria shown using the scale below each question. As you answer each question, choose the answer that best describes how you have felt and conducted yourself <b>over the past 6 months</b>.</p>

<hr />

<form id="quizzes">
<?PHP
foreach ($aQuestion as $iQuestion => $sQuestion) {
	$iQuestion++;
	echo "<div class=\"question\">";
	echo "<p class=\"question\">".sprintf("%02d", $iQuestion).". ".htmlspecialchars($sQuestion)."</p>";
	echo "<p class=\"answer\">";
	foreach ($aAnswer as $iAnswer => $sAnswer) {
		echo "<label><input type=\"radio\" name=\"q".$iQuestion."\" value=\"".$iAnswer."\" />".$sAnswer."<br /></label>";
	}
	echo "</p>";
	echo "</div>";
}
?>

<p class="button"><button>对我的答卷进行评分</button><button>清空答卷</button></p>
</form>

<div class="result">
<div class="score">17</div>
<p>You have answered this self-report questionnaire in such a way as to suggest that you do not likely currently suffer from an attention deficit disorder. You should not take this as a diagnosis or recommendation for treatment in any way, though. You experience the normal ups and downs of life.<br /><img src="http://psychcentral.com/images/adhd_free.gif" /></p>
<p>Based upon your responses to this adult ADHD screening quiz, you may very well have an adult attention deficit disorder. People who have answered similarly to you typically qualify for a diagnosis of ADHD or ADD and have sought professional treatment for this disorder. <br />You should not take this as a diagnosis of any sort, or a recommendation for treatment. However, if would be advisable and likely beneficial for you to seek further diagnosis from a trained mental health professional soon to rule out a possible attention deficit disorder.<br /><img src="http://psychcentral.com/images/adhd_mild.gif" /></p>
<p>Based upon your responses to this adult ADHD screening quiz, you appear to be suffering from adult a attention deficit disorder. People who have answered similarly to you typically qualify for a diagnosis of ADHD or ADD and have sought professional treatment for this disorder.<br />You should not take this as a diagnosis of any sort, or a recommendation for treatment. However, it would be advisable and likely beneficial for you to seek further diagnosis from a trained mental health professional immediately.<br /><img src="http://psychcentral.com/images/adhd_serious.gif"></p>
</div>

<script>
var aLevel = [12, 16];
</script>

<p>英文原版 <a href="http://psychcentral.com/quizzes/adultaddquiz.htm">http://psychcentral.com/quizzes/adultaddquiz.htm</a></p>
<div>
</body>
</html>