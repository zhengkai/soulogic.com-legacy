<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>注意力缺陷障碍（成人多动症，ADD/ADHD）测试</title>
<link rel="canonical" href="http://soulogic.com/adhd/" />
<link rel="stylesheet" href="style.css" type="text/css" />
<script type="text/javascript" src="script.js"></script>
</head>

<body>

<?PHP
$aQuestion = array(
	'At home, work, or school, I find my mind wandering from tasks that are uninteresting or difficult.',
	'I find it difficult to read written material unless it is very interesting or very easy.',
	'Especially in groups, I find it hard to stay focused on what is being said in conversations.',
	'I have a quick temper... a short fuse.',
	'I am irritable, and get upset by minor annoyances.',
	'I say things without thinking, and later regret having said them.',
	'I make quick decisions without thinking enough about their possible bad results.',
	'My relationships with people are made difficult by my tendency to talk first and think later.',
	'My moods have highs and lows.',
	'I have trouble planning in what order to do a series of tasks or activities.',
	'I easily become upset.',
	'I seem to be thin skinned and many things upset me.',
	'I almost always am on the go.',
	'I am more comfortable when moving than when sitting still.',
	'In conversations, I start to answer questions before the questions have been fully asked.',
	'I usually work on more than one project at a time, and fail to finish many of them.',
	'There is a lot of "static" or "chatter" in my head.',
	'Even when sitting quietly, I am usually moving my hands or feet.',
	'In group activities it is hard for me to wait my turn.',
	'My mind gets so cluttered that it is hard for it to function.',
	'My thoughts bounce around as if my mind is a pinball machine.',
	'My brain feels as if it is a television set with all the channels going at once.',
	'I am unable to stop daydreaming.',
	'I am distressed by the disorganized way my brain works.',
);

$aAnswer = array(
	'Not at all',
	'Just a little',
	'Somewhat',
	'Moderately',
	'Quite a lot',
	'Very much',
);
?>
<div style="width: 960px; margin: 0 auto;">
<h1>注意力缺陷障碍（成人多动症，ADD/ADHD）测试</h1>

<p class="author">Jasper/Goldberg Adult ADD/ADHD Screening Quiz<br />
by Larry Jasper & Ivan Goldberg</p>

<p class="description">Use this questionnaire to help determine if you need to see a mental health professional for diagnosis and treatment of ADD or ADHD in an adult. We also have a <a href="./quick.php">6-question, short ADD quiz</a>.</p>
<p class="description"><b>Instructions:</b> The 24 items below refer to how you have behaved and felt <b>DURING MOST OF YOUR ADULT LIFE</b>. If you have usually been one way and recently have changed, your responses should reflect <b>HOW YOU HAVE USUALLY BEEN</b>. For each item, indicate the extent to which it is true by checking the appropriate box next to the item.</p>

<hr />

<form id="quizzes">
<?PHP
foreach ($aQuestion as $iQuestion => $sQuestion) {
	$iQuestion++;
	echo "<div class=\"question\">";
	echo "<p class=\"question\">".sprintf("%02d", $iQuestion).". ".htmlspecialchars($sQuestion)."</p>";
	echo "<p class=\"answer\">";
	foreach ($aAnswer as $iAnswer => $sAnswer) {
		echo "<label><input type=\"radio\" name=\"q".$iQuestion."\" value=\"".$iAnswer."\" />".$sAnswer."<br /></label>";
	}
	echo "</p>";
	echo "</div>";
}
?>

<p class="button"><button>对我的答卷进行评分</button><button>清空答卷</button></p>
</form>

<div class="result">
<div class="score">17</div>
<p>You have answered this self-report questionnaire in such a way as to suggest that you do not likely currently suffer from an attention deficit disorder. You should not take this as a diagnosis or recommendation for treatment in any way, though.<br /><img src="http://psychcentral.com/images/adhd_free.gif" /></p>
<p>You appear to experiencing some type of attention and concentration problems which are often common amongst the general population, but border on the possibility of being more severe. It is unclear as to whether you suffer these problems severely enough to need to seek further diagnosis and treatment of them. You should not take your responses to this self-report questionnaire as a diagnosis or recommendation for treatment of any sort. Consult with a trained mental health professional if you are experiencing difficulties in your daily functioning that you are worried about.<br /><img src="http://psychcentral.com/images/adhd_borderline.gif" /></p>
<p>You appear to suffer from mild attention and concentration difficulties according to your responses to this self-report questionnaire. You should not take this as a diagnosis of any sort, or a recommendation for treatment. However, you may want to look into seeking further consultation with a trained mental health professional if you are experiencing any difficulties in daily functioning due to these difficulties or if you'd like a more in-depth answer.<br /><img src="http://psychcentral.com/images/adhd_mild.gif" /></p>
<p>You appear to be suffering from a moderate amount of attention and concentration difficulties according to your responses to this self-report questionnaire. You should not take this as a diagnosis of any sort, or a recommendation for treatment. However, it would be advisable and likely beneficial for you to seek further diagnosis from a trained mental health professional soon to rule out a possible attention disorder.<br /><img src="http://psychcentral.com/images/adhd_moderate.gif" /></p>
<p>It is highly likely that you are presently suffering from adult attention deficit disorder, according to your responses on this self-report questionnaire. You should not take this as a diagnosis of any sort, or a recommendation for treatment. However, it would be advisable and likely beneficial for you to seek further diagnosis from a trained mental health professional <b>immediately</b>.<br /><img src="http://psychcentral.com/images/adhd_serious.gif" /></p>
</div>

<script>
var aLevel = [25, 35, 50, 70];
</script>

<p>英文原版 <a href="http://psychcentral.com/addquiz.htm">http://psychcentral.com/addquiz.htm</a></p>
<div>
</body>
</html>